import { useState } from "react";
import { motion } from "framer-motion";

export default function Funnel() {
  const [lead, setLead] = useState({ name: "", email: "" });
  const [loading, setLoading] = useState(false);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setLead((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = async () => {
    if (!lead.name || !lead.email) {
      alert("Please fill in both name and email");
      return;
    }
    setLoading(true);
    try {
      const res = await fetch("/api/lead", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(lead),
      });
      if (res.ok) {
        alert("✅ Success! Preview chapter sent to your email.");
        setLead({ name: "", email: "" });
      } else {
        alert("❌ Something went wrong. Try again.");
      }
    } catch (err) {
      console.error(err);
      alert("❌ Server error. Try again.");
    }
    setLoading(false);
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-gray-50 to-white text-gray-900">
      <div className="text-center py-8 border-b-2 border-blue-600">
        <span className="text-5xl font-black text-blue-600">DIGITAL</span>
        <span className="text-5xl font-black text-black ml-1">ENVISIONED</span>
      </div>

      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.8 }}
        className="max-w-3xl mx-auto px-6 py-12 text-center"
      >
        <h1 className="text-4xl font-black mb-6">
          Unlock the 7 Digital Secrets Every Business Owner Needs
        </h1>
        <p className="mb-8 text-lg text-gray-700">
          Enter your details to get your free executive preview chapter.
        </p>

        <div className="flex flex-col gap-4">
          <input
            type="text"
            name="name"
            value={lead.name}
            onChange={handleChange}
            placeholder="Your Name"
            className="p-4 rounded-lg text-black text-lg"
          />
          <input
            type="email"
            name="email"
            value={lead.email}
            onChange={handleChange}
            placeholder="Your Best Email"
            className="p-4 rounded-lg text-black text-lg"
          />
          <button
            onClick={handleSubmit}
            disabled={loading}
            className="bg-yellow-400 hover:bg-yellow-500 text-black px-8 py-4 text-lg font-bold rounded-lg shadow-lg"
          >
            {loading ? "Sending..." : "Send Me The Free Preview →"}
          </button>
        </div>
      </motion.div>
    </div>
  );
}
